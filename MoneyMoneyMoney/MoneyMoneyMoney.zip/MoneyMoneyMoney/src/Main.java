public class Main {
    public static void main(String[] args) {


        Person person1 = new Person("João",1000,0;
        Wallet saco = new Wallet(0);






    }
}