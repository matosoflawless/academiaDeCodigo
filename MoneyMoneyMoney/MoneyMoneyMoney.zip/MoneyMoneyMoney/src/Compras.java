public enum Compras {
    PELUCHE,
    GARRAFADEVINHO,
    CADEIRA,
    CARRO
}
