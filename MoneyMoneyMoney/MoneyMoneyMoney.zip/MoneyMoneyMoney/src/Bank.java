public class Bank {


    //nesta class vamos poder adicionar ou tirar dinheiro usando a PERSON.
    //precisamos do actualMoney, para gerir a entrada e saida de dinheiro do banco, so a person e que pode meter ou tirar

    int moneyIncome;
    int moneyOutcome;


    //Construtor


    public  int withrall(int withinNum) {

        return (actualMoney = actualMoney - moneyGet);
    }
    public  int deposit(int depositNum){
            moneyIncome

    }




    public int getActualMoneyMoney() {
        return actualMoney;
    }

    public void setActualMoney(int depositMoney) {
        this.actualMoney = depositMoney;
    }
}
