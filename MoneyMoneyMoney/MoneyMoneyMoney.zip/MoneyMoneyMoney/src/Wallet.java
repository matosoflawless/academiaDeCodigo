public class Wallet {


    int currentMoney;

    public Wallet(int currentMoney) {
        this.currentMoney = currentMoney;
    }


    public void buildWallet(int money) {
        this.currentMoney = money;
    }
    public int getCurrentMoney() {
        return currentMoney;
    }


    public void setCurrentMoney(int insertMoney) {
        this.currentMoney = insertMoney;
    }


}
